/*
 * Revision Control Information
 *
 * $Source: /users/pchong/CVS/sis/sis/gcd/gcd.h,v $
 * $Author: pchong $
 * $Revision: 1.1.1.1 $
 * $Date: 2004/02/07 10:14:23 $
 *
 */
#ifndef GCD_H
#define GCD_H

EXTERN array_t *gcd_prime_factorize ARGS((node_t *));
EXTERN node_t *gcd_nodevec ARGS((array_t *));

#endif
